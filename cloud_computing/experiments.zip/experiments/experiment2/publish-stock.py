import zmq
import random
import sys
import time


class publish_stock:

    def __init__(self):

        self.port = "5555"
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUB)
        self.socket.bind("tcp://*:%s" % self.port)


    def publish(self):

        j=0

        while (j <= 10):
            messagedata = random.randrange(1,215)
            self.socket.send(b'stock-GOOG '+bytes([messagedata]))
            print("stock-GOOG ",messagedata)
            j=j+1
            time.sleep(1)


    def bandwidth_test(self):
        with open("1MB", "r") as file:
            data = file.read()
            self.socket.send(b'stock-GOOG '+bytes(data,'utf-8'))


def main():
    pub = publish_stock()
    pub.publish()
    pub.bandwidth_test()


if __name__ == "__main__":
    main()