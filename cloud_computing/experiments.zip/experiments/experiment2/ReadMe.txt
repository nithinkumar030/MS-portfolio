This is the Mininet experiment for SDN-based pub-sub. The topology is as follow: 

         Pox SDN controller
     h4 /
      |/
h1 - s1 - h3 
      |     
      h2
       
h1 runs publish-stock.py and h3 runs subscribe-stock.py.

h2 runs publish-weather.py and h4 runs subscribe-weather.py.

1. Install pyzmq using pip3 install pyzmq

2. Install the POX SDN controller from git hub

$ git clone http://github.com/noxrepo/pox



3.open the ./pox/pox/forwarding/l2_learning.py and replace the l2_learning.py with the attached one.  

start the POX using command - ./pox.py forwarding.l2_learning

4. Mininet experiment: 
  A. Create the above Mininet topology. 
    a. sudo mn --mac -x --controller=remote --switch=ovsk,protocol=OpenFlow13 --topo=single,4



5. Apply the Qos configuration of the S1 switch in xterm

ovs-vsctl -- set Port s1-eth1 qos=@newqos -- \
--id=@newqos create QoS type=linux-htb other-config:max-rate=1000000000 queues=0=@q0,1=@q1 -- \
--id=@q0 create Queue other-config:min-rate=1000000000 other-config:max-rate=1000000000 -- \
--id=@q1 create Queue other-config:min-rate=4000000 other-config:max-rate=4000000

ovs-vsctl -- set Port s1-eth2 qos=@newqos -- \
--id=@newqos create QoS type=linux-htb other-config:max-rate=1000000000 queues=0=@q0,1=@q1 -- \
--id=@q0 create Queue other-config:min-rate=1000000000 other-config:max-rate=1000000000 -- \
--id=@q1 create Queue other-config:min-rate=4000000 other-config:max-rate=4000000


ovs-vsctl -- set Port s1-eth3 qos=@newqos -- \
--id=@newqos create QoS type=linux-htb other-config:max-rate=1000000000 queues=0=@q0,1=@q1 -- \
--id=@q0 create Queue other-config:min-rate=1000000000 other-config:max-rate=1000000000 -- \
--id=@q1 create Queue other-config:min-rate=4000000 other-config:max-rate=4000000


ovs-vsctl -- set Port s1-eth4 qos=@newqos -- \
--id=@newqos create QoS type=linux-htb other-config:max-rate=1000000000 queues=0=@q0,1=@q1 -- \
--id=@q0 create Queue other-config:min-rate=1000000000 other-config:max-rate=1000000000 -- \
--id=@q1 create Queue other-config:min-rate=4000000 other-config:max-rate=4000000
   
  
6.
  B. Type python3 publish_stock.py on xterm h1   and Type python3 subscribe_stock.py on  xterm h3.

  C. Type python3 publish_weather.py on xterm h2  and Type python3 subscribe_weather.py on  xterm h4.  
   
  D. observe that the bandwidth allocated for stock topic is always greater than weather topic

