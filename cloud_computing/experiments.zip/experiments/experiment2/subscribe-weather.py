import sys
import zmq
import time


class subscribe_weather:

    def __init__(self):

        self.port = "5556"
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.SUB)

        print("Collecting updates from weather server...")
        self.socket.connect ("tcp://10.0.0.2:%s" % self.port)

        self.socket.setsockopt(zmq.SUBSCRIBE, b"weather-Nashville")


    def subscribe(self):

        j=0
        while (j < 10):
            string = self.socket.recv()
            try:
                topic, messagedata = string.split()
                i=int.from_bytes(messagedata,'little')
                print(str(topic)+':' +str(i))
            except ValueError:
                print(string)
            j=j+1
            time.sleep(1)

    def bandwidth_test(self):

        t1= time.time()
        data = self.socket.recv()
        t2=time.time()

        print("Topic BandWidth in Mbps= ",sys.getsizeof(data)*8/((t2-t1)*1024*1024))


def main():
    sub_weather = subscribe_weather()
    sub_weather.subscribe()
    sub_weather.bandwidth_test()



if __name__ == "__main__":
    main()