import zmq
import random
import sys
import time


class publish_weather:

    def __init__(self):

        self.port = "5556"
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUB)
        self.socket.bind("tcp://*:%s" % self.port)


    def publish(self):

        j=0

        while (j <= 10):
            messagedata = random.randrange(1,50)
            self.socket.send(b'weather-Nashville '+bytes([messagedata]))
            print("weather-Nashville ",messagedata)
            j=j+1
            time.sleep(1)


    def bandwidth_test(self):
        with open("1MB", "r") as file:
            data = file.read()
            self.socket.send(b'weather-Nashville '+bytes(data,'utf-8'))


def main():
    pub_weather = publish_weather()
    pub_weather.publish()
    pub_weather.bandwidth_test()


if __name__ == "__main__":
    main()