def get_times (file_path): 
  f = open (file_path, 'r') 
  times = [] 
  for line in f.readlines (): 
    times.append (float (line)) 
  f.close () 
  return times 

def cal_avg (file_path1, file_path2): 
  times1 = get_times (file_path1) 
  times2 = get_times (file_path2) 
  res_times = []
  n = len (times2)
  for i in range (n): 
    res_times.append (times2[i] - times1[i]) 
  return sum (res_times) / n 
  
def main (): 
  res_avg1 = cal_avg ('kafka-pub-sub/sender.txt', 'kafka-pub-sub/receiver.txt') 
  res_avg2 = cal_avg ('SDN-pub-sub/sender.txt', 'SDN-pub-sub/receiver.txt') 
  print ('kafka-based pub-sub: ', res_avg1) 
  print ('SDN-based pub-sub: ', res_avg2) 
  
if __name__ == '__main__': 
  main () 
