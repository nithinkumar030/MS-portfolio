import time
import zmq
import socket
import struct 
import hashlib 


class Publisher: 
  def __init__ (self): 
    self.topic_radio = {} 
    
  def publish_init (self, topic, priority): 
    ctx = zmq.Context () 
    radio = ctx.socket (zmq.RADIO) 
    ip_addr = get_ip_address (topic, priority) 
    radio.connect (ip_addr) 
    self.topic_radio[topic] = radio 
    
    print (ip_addr)
    
  def publish (self, radio, data, group = 'numbers'): 
    radio.send (bytes (str (data), 'utf-8'), group = group) 
    
    
def get_ip_address (topic, priority): 
  b = bytes (topic, 'utf-8')
  m = hashlib.md5 () 
  m.update (b) 
  res = m.digest () 
  ip_a = str (hex (int.from_bytes (res, "little")))
  ip_a16 = ip_a[3:7] 
  mcast_ip =  ip_a16+'F'+str (priority)+'E8'   #'E1'+ str(priority)+'F'+ip_a16 
  int_m_ip_a = int (mcast_ip, 16) 
  mcast_ip_a = socket.inet_ntoa (struct.pack ("<L", int_m_ip_a)) 
  ip_addr = 'udp://'+mcast_ip_a+':5556' 
  return ip_addr 

def main():
  pub = Publisher () 
  topic = "weather"
  pub.publish_init (topic, 4) 
  radio = pub.topic_radio[topic] 
  times = []
  for i in range (100): 
    times.append (time.time ())
    pub.publish (radio, "123") 
    time.sleep (0.1) 
  save_time (times, "sender.txt") 

def save_time (times, file_path): 
  f = open (file_path, "a") 
  for time in times: 
    f.write (str (time)) 
    f.write ("\n")
  f.close () 


if __name__ == "__main__":
  main()

