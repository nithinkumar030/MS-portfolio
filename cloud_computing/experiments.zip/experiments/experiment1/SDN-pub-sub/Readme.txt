This is the Mininet experiment for SDN-based pub-sub. The topology is as follow: 
	s1 - s2 - s3 
	 |    |    | 
	h1   h2   h3 
h1 runs pub.py and h2 runs sub.py. 


1. Download pyzmq with draft. This is because radio-dish pattern needs draft enabled. 
  a. sudo su 
  b. wget https://github.com/zeromq/libzmq/releases/download/v4.2.2/zeromq-4.2.2.tar.gz -O libzmq.tar.gz 
  c. tar -xzf libzmq.tar.gz 
  d. cd zeromq-4.2.2 
  e. ./configure --prefix=/usr/local --enable-drafts 
  f. make -j && sudo make install 
  g. python3 -m pip install -v --pre pyzmq --install-option=--enable-drafts 
  
2. Mininet expeiment: 
  A. Create the above Mininet topology. 
    a. sudo mn --topo linear,3
  B. Add multicast route for h1 and h3. 
    a. h1 ip route add 232.244.78.151 dev h1-eth0
    b. h3 ip route add 232.244.78.151 dev h3-eth0 
  C. For h3: 
    a. Use `xterm h3` to open a shell for h3. 
    b. In the shell, first go to the directory of this file. 
    c. then use `python3 sub.py` to start the subscriber. 
  D. For h1: 
    a. Use `xterm h1` to open a shell for h1. 
    b. In the shell, first go to the directory of this file. 
    c. then use `python3 pub.py` to start the subscriber. 
  E. Then receiver.txt and sender.txt will be generated. The difference of receive and send time is the response time we need. 
