import time
import zmq
from pub import get_ip_address, save_time 


class Subscriber: 
  def __init__ (self, topic, priority, group = 'numbers'): 
    ctx = zmq.Context () 
    self.dish = ctx.socket (zmq.DISH) 
    ip_addr = get_ip_address (topic, priority) 
    self.dish.bind (ip_addr) 
    self.dish.join (group) 
    
    print (ip_addr)
    
  def subscribe (self): 
    times = [] 
    for i in range (100): 
      self.dish.recv (copy = False) 
      times.append (time.time ()) 
    return times 
    

def main(): 
  sub = Subscriber ("weather", 4) 
  times = sub.subscribe () 
  save_time (times, "receiver.txt") 


if __name__ == "__main__":
  main()

