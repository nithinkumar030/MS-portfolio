import os   
import time
from kafka import KafkaConsumer 


class Subscriber: 
  def __init__ (self, kafka_addr):
    self.consumer = KafkaConsumer (bootstrap_servers = kafka_addr) 
    
  def subscribe (self, topics = ["topic0"]): 
    self.consumer.subscribe (topics = topics)
    
  def save_time (self, time, file_path): 
    f = open (file_path, "a") 
    f.write (str (time)) 
    f.write ("\n")
    f.close () 
    
  def run (self): 
    self.subscribe () 
    for msg in self.consumer: 
      self.save_time (time.time (), "receiver.txt") 
    self.consumer.close () 
    
    
if __name__ == "__main__": 
  sub = Subscriber ("10.0.0.2:9092")
  sub.run () 
