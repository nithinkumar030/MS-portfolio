This is the Mininet experiment for pub-sub with broker. The topology is as follow: 
	s1 - s2 - s3 
	 |    |    | 
	h1   h2   h3 
	
	
1. Download Apache Kafka: 
  A. Download Java: 
    a. sudo apt update 
    b. sudo apt install default-jdk 
  B. Download Kafka: 
    a. wget http://www-us.apache.org/dist/kafka/2.4.0/kafka_2.13-2.4.0.tgz
    b. tar xzf kafka_2.13-2.4.0.tgz
    c. mv kafka_2.13-2.4.0 /usr/local/kafka

2. Replace Kafka server.properties file: 
  a. sudo mv server.properties /usr/local/kafka/config/server.properties

3. Download kafka-python package for Python: 
  a. sudo su 
  b. python3 -m pip install kafka-python 
  
4. Mininet: 
  A. Start Mininet: 
    a. sudo mn --topo linear,3 
  B. For h2: 
    a. Use `xterm h2` twice to open 2 terminals. 
    b. In the first one, use `/usr/local/kafka/bin/zookeeper-server-start.sh /usr/local/kafka/config/zookeeper.properties` to run zookeeper server. 
    c. In the second one, `/usr/local/kafka/bin/kafka-server-start.sh /usr/local/kafka/config/server.properties` to run kafka server. 
  C. For h3: 
    a. Use `xterm h3` to open a ternimal. 
    b. Go to the directory of this file. 
    c. Use `python3 sub.py` to run subscriber. 
  D. For h1: 
    a. Use `xterm h1` to poen a ternimal. 
    b. Go to the directory of this file. 
    c. Use `python3 pub.py` to run publisher. 
    
5. The message sending time and receiving time is stored in sender.txt and receiver.txt files. The difference of them is the response time we need. 





