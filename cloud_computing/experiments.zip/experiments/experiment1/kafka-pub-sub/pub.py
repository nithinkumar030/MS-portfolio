import os   
import time 
from kafka import KafkaProducer


class Publisher: 
  def __init__ (self, kafka_addr):
    self.producer = KafkaProducer (bootstrap_servers = kafka_addr, acks = 1) 
    
  def publish (self, topic = "topic0", data = bytes ("123", "ascii")): 
    self.producer.send (topic = topic, value = data) 
    self.producer.flush () 
    
  def save_time (self, times, file_path): 
    f = open (file_path, "a") 
    for time in times: 
      f.write (str (time)) 
      f.write ("\n")
    f.close () 
    
  def run (self): 
    times = []
    for i in range (100): 
      times.append (time.time ()) 
      self.publish () 
      time.sleep (0.1) 
    self.producer.close () 
    self.save_time (times, "sender.txt") 
    
    
if __name__ == "__main__": 
  pub = Publisher ("10.0.0.2:9092")
  pub.run () 
    
