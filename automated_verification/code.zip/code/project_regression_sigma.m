%cd 'C:\Users\All\Documents\3rd-semester\Automated-verification-CS6315\project\nnv-master\nnv-master\code\nnv'
%startup_nnv
%cd '../../../..'

%load the net_tan as CNN network - net_tan_nnv_hd is got from .mat file
net_tan_nnv_hd = load('nnvnet_HD')


% input X - 2 sigma
lb = [0.158487;0.227642;	0.098605;	0.140091;	0.174804	;0.09409;	0.187382	;0.460418;	0.177154;	0.141214;	0.17691	;0.313841;	0.238624;	0.268424;	0.255859;	0.307897;	0.231163;	0.272687;	0.264752;	0.385249;	0.227117;	0.207643;	0.531006;	0.228845;	0.380158;	0.195891;	0.541035;	0.41303;	0.494729
];

% input X +2 sigma
ub = [0.990987;	0.892886;	0.845809;	0.825611;	0.748776;	0.733422;	0.724014;	0.863098;	0.77573	;0.698638;	0.824278;	0.888777;	0.800788;	0.815376;	0.851399;	0.848501;	0.742311;	0.778079;	0.6891;	0.724257;	0.547689;	0.772111;	0.731922;	0.613545;	0.739254;	0.583415;	0.815119;	0.579502;	0.946533
];


% create a startset from lb and ub
s1 = Star(lb,ub);

% convert to imagestar to feed into CNN nnv net
I1=s1.toImageStar(29,1,1);
% convert to imagestar to feed into CNN nnv net
I2=s1.toImageStar(1,29,1);


[IS1,reachTime1] = net_tan_nnv_hd.nnvnet_HD.reach(I1);

[IS2,reachTime2] = net_tan_nnv_hd.nnvnet_HD.reach(I2);

[lb1, ub1] = IS1.getRanges;
[lb2, ub2] = IS2.getRanges;

lb1 = reshape(lb1, [1 29]);
ub1 = reshape(ub1, [1 29]);


im_center1 = (lb1 + ub1)/2;
err1 = (ub1 - lb1)/2;
x1 = 0:1:28;
y1 = im_center1;

lb2 = reshape(lb2, [1 29]);
ub2 = reshape(ub2, [1 29]);

im_center2 = (lb2 + ub2)/2;
err2 = (ub2 - lb2)/2;
x2 = 0:1:28;
y2 = im_center2;


figure;

subplot(1,3,1);
e = errorbar(x1,y1,err1);
e.LineStyle = 'none';
e.LineWidth = 1;
e.Color = 'red';
xlabel('Output', 'FontSize', 11);
ylabel('Ranges', 'FontSize', 11);
xlim([0 29]);
title('ImageStar', 'FontSize', 11);
xticks([0 15 29]);
xticklabels({'0', '15', '29'});
set(gca, 'FontSize', 30);


subplot(1,3,1);
e1 = errorbar(x2,y2,err2);
e1.LineStyle = 'none';
e1.LineWidth = 1;
e1.Color = 'red';
xlabel('Output', 'FontSize', 11);
ylabel('Ranges', 'FontSize', 11);
xlim([0 29]);
title('ImageStar', 'FontSize', 11);
xticks([0 15 29]);
xticklabels({'0', '15', '29'});
set(gca, 'FontSize', 30);




